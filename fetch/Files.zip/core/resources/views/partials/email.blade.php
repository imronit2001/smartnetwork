@php echo  $body @endphp
